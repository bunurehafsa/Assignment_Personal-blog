
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy;  <a href="http://trainingwithliveproject.com">Nure Hafsa Shefa</a>. All Rights Reserved.
        </p>
    </div>
</body>
</html>