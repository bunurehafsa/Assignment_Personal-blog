<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_blog");
define("TITLE", "Training With Live Project");
define("KEYWORDS", "PHP Tutorials, JAVA Tutorials, Oracle Database, C# Tutorials");

